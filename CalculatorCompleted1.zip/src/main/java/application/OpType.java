package application;

/**
 * Codifies the types of expression that we can calculate.
 */
public enum OpType {
  STANDARD, REV_POLISH
}
